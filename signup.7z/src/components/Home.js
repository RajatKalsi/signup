import React from 'react'

function Home({ login }) {
    return (
        <div className='row'>
            <div className='col-4'>
                <h1>rjgdshgn vjfn

                    {/* {
                        login.map((value) => {
                            return (
                                <>
                                    <p>{value}</p>
                                </>
                            )
                        })

                    } */}
                </h1>

            </div>
        </div>
    )
}

export default Home